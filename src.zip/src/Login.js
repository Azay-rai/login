import React, { useState } from 'react';

const Login = ({ handleSignupClick }) => {
  const [credentials, setCredentials] = useState({
    email: '',
    password: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setCredentials({ ...credentials, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    let req = new XMLHttpRequest();

    req.open('GET', 'https://api.jsonbin.io/v3/b/66edc259e41b4d34e433f700/latest', true);
    req.setRequestHeader('X-Master-Key', '$2a$10$ToZWzptdp8n/w6Sc1RPpyOhA34hTnX34qphoPoxBjzvGU34Ix8wJC');

    req.onreadystatechange = () => {
      if (req.readyState === XMLHttpRequest.DONE && req.status === 200) {
        const binData = JSON.parse(req.responseText);
        const userFound = binData.record.find(user => user.email === credentials.email && user.password === credentials.password);

        if (userFound) {
          alert('Login Successful');
          // Redirect or perform further actions
        } else {
          alert('Invalid email or password');
        }
      }
    };

    req.send();
  };

  return (
    <div className="login-container">
      <h2 className="text-center">Login Form</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label htmlFor="email" className="form-label">Email</label>
          <input
            type="email"
            className="form-control"
            id="email"
            name="email"
            value={credentials.email}
            onChange={handleChange}
            required
          />
        </div>
        <div className="mb-3">
          <label htmlFor="password" className="form-label">Password</label>
          <input
            type="password"
            className="form-control"
            id="password"
            name="password"
            value={credentials.password}
            onChange={handleChange}
            required
          />
        </div>
        <button type="submit" className="btn btn-primary">Login</button>
        <button type="button" className="btn btn-link" onClick={handleSignupClick}>
          Don't have an account? Go to Signup
        </button>
      </form>
    </div>
  );
};

export default Login;
