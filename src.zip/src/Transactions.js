import React from 'react';

const Transactions = () => {
  return (
    <div className="transaction-container">
      <h2 className="text-center">Transaction Form</h2>
      {/* Your transaction form or transaction history code goes here */}
      <form>
        {/* Example input fields */}
        <div className="mb-3">
          <label htmlFor="amount" className="form-label">Amount</label>
          <input type="number" className="form-control" id="amount" required />
        </div>
        <div className="mb-3">
          <label htmlFor="description" className="form-label">Description</label>
          <input type="text" className="form-control" id="description" required />
        </div>
        <button type="submit" className="btn btn-primary">Submit Transaction</button>
      </form>
    </div>
  );
};

export default Transactions;
