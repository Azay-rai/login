import React, { useState } from 'react';
import Signup from './Signup';
import Login from './Login';

const App = () => {
  const [isLogin, setIsLogin] = useState(false);

  const handleLoginClick = () => {
    setIsLogin(true);
  };

  const handleSignupClick = () => {
    setIsLogin(false);
  };

  return (
    <div className="app-container">
      {isLogin ? (
        <Login handleSignupClick={handleSignupClick} />
      ) : (
        <Signup handleLoginClick={handleLoginClick} />
      )}
    </div>
  );
};

export default App;
